import json,hashlib,subprocess,difflib
from pathlib import Path
B=Path('/workspace/work/w004');R=B/'review-r3/snapshot';F=R/'tests/fixtures/w003_m1';O=B/'reviewer/final-audit';O.mkdir(exist_ok=True)
j=lambda p:json.loads(p.read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=j(B/'review-r3/SHA256SUMS.json');assert h(B/'review-r3/SHA256SUMS.json')=='9136e0509ab50e03ea260eb0d1ecaedfb4aa6a58cda17a5cc926d715de0fbd76'
assert all(h(R/p)==v for p,v in m.items())
m2=j(B/'review-r2/SHA256SUMS.json');diff=[p for p in sorted(set(m)|set(m2)) if m.get(p)!=m2.get(p)]
assert diff==['docs/tasks/W003/revision-evidence.md','docs/tasks/W004-fixture-revision.md','tests/support/w003_verify.py'],diff
s=j(F/'spec.json');src=j(F/'sources.json');ctx=j(F/'body/context.json')
assert {x['object']:x['actual_bbox_nm'] for x in src['dimensions']}=={x['id']:x['bbox'] for x in s['shapes']}
assert {x['object']:x['bbox_nm'] for x in src['external_dimensions']}=={x['id']:x['bbox'] for x in ctx['shapes']}
for x in src['dimensions']:assert x['actual_size_xy_nm']==[x['actual_bbox_nm'][2]-x['actual_bbox_nm'][0],x['actual_bbox_nm'][3]-x['actual_bbox_nm'][1]]
for x in src['external_dimensions']:assert x['size_xy_nm']==[x['bbox_nm'][2]-x['bbox_nm'][0],x['bbox_nm'][3]-x['bbox_nm'][1]]
pol=j(F/'validation_policy.json');recs=j(R/'docs/tasks/W003/examples/records.json')['records'];rep=j(R/'docs/tasks/W003/examples/report.expected.json');md=(R/'docs/tasks/W003/examples/report.expected.md').read_text()
assert pol['check_obligations']==rep['check_obligations'];assert pol['deferred']==rep['deferred'];assert rep['deployment_disposition']=='requires_review'
checks={x['check_id']:x for z in recs if z['kind']=='ValidationResult' for x in z['checks']}
for obligation in pol['check_obligations']:
 row='| '+' | '.join([obligation['check_id'],', '.join(obligation['inputs']),obligation['expected_proof'],obligation['status'],obligation['original_obligation']])+' |';assert row in md
 assert obligation['check_id'] in checks
for cid in pol['deferred']:
 c=checks[cid];assert c['execution_status']=='deferred' and c['coverage']=='none' and c['policy_disposition']=='requires_review' and c['runtime_ms'] is None and c['return_code'] is None
reg=B/'validation-r4/regenerated-fixture';files={str(p.relative_to(F)) for p in F.rglob('*') if p.is_file()};files2={str(p.relative_to(reg)) for p in reg.rglob('*') if p.is_file()};assert files==files2 and len(files)==116
assert all((F/p).read_bytes()==(reg/p).read_bytes() for p in files)
assert (R/'docs/tasks/W003/fixture-layout.png').read_bytes()==(B/'validation-r4/regenerated-layout.png').read_bytes()
report_files=['schema.json','records.json','failures.json','report.expected.json','report.expected.md']
for p in report_files:assert (R/'docs/tasks/W003/examples'/p).read_bytes()==(B/'validation-r4/record-regeneration-root/docs/tasks/W003/examples'/p).read_bytes()
ref_counts={}
for fn in ['records.json','failures.json','report.expected.json']:
 refs=[]
 def walk(v):
  if isinstance(v,dict):
   if 'path' in v:refs.append(v)
   for x in v.values():walk(x)
  elif isinstance(v,list):
   for x in v:walk(x)
 walk(j(R/'docs/tasks/W003/examples'/fn))
 for ref in refs:
  fp=F/ref['path'];assert h(fp)==ref['actual_byte_sha256']
  if ref['json_pointer']:
   z=j(fp)
   for token in ref['json_pointer'].split('/')[1:]:
    key=token.replace('~1','/').replace('~0','~');z=z[int(key)] if isinstance(z,list) else z[key]
 ref_counts[fn]=len(refs)
assert sum(ref_counts.values())==133
cmd=j(B/'validation-r4/commands.json');assert len(cmd)==6 and all(x['returncode']==0 for x in cmd)
for x in cmd:assert not (B/'validation-r4'/x['stderr']).read_bytes()
base='9f6735dcede8e8b2135f89ff10f079a752ed758b';repo=Path('/workspace/Layauto')
protected=['AGENTS.md','README.md','docs/architecture.md','docs/current-work.md','docs/collaboration/rules.md','docs/tasks/W003-m1-fixture-contracts.md','docs/tasks/W003/manual-verification.md','docs/tasks/W003/web-codex-handoff.md']
for p in protected:assert subprocess.check_output(['git','show',f'{base}:{p}'],cwd=repo)==(R/p).read_bytes()
orig=subprocess.check_output(['git','show',f'{base}:docs/tasks/W004-fixture-revision.md'],cwd=repo).decode();new=(R/'docs/tasks/W004-fixture-revision.md').read_text();changes=[x for x in difflib.SequenceMatcher(a=orig.splitlines(keepends=True),b=new.splitlines(keepends=True),autojunk=False).get_opcodes() if x[0]!='equal'];assert len(changes)==2 and all(x[0]=='insert' for x in changes),changes
x=changes[-1];added=''.join(new.splitlines(keepends=True)[x[3]:x[4]]);assert '### E3.' in added and '### E1.' not in added and '### E2.' not in added and '### RP1.' not in added
out={'snapshot_manifest_sha256':h(B/'review-r3/SHA256SUMS.json'),'snapshot_files_verified':len(m),'r2_to_r3_changed_only':diff,'actual_dimension_table_local_external':[40,6],'D3_obligations_policy_machine_human_equal':len(pol['check_obligations']),'actual_file_bytes_and_JSON_pointers_independently_verified':ref_counts,'real_checks_retained_deferred_none_requires_review':pol['deferred'],'regenerated_fixture_exact_bytes_files':len(files),'regenerated_plot_sha256':h(B/'validation-r4/regenerated-layout.png'),'regenerated_record_report_files_exact':report_files,'recorded_main_commands_all_zero':len(cmd),'protected_originals_byte_unchanged':protected,'W004_historical_text_only_insertion':True,'caveat':'Independent verification of saved main regeneration artifacts/commands; not reviewer claim to have rerun main generation. Final binary patch packaging outside reviewed snapshot pending integrator audit.'}
(O/'result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

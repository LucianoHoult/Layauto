import re,json,subprocess,hashlib
from pathlib import Path
R=Path('/workspace/Layauto'); files=['tests/fixtures/w003_m1/README.md','docs/tasks/W003/README.md','docs/tasks/W003/contracts.md','docs/tasks/W003/handoff.md','docs/tasks/W003/revision-evidence.md','docs/tasks/W003/examples/report.expected.md','docs/tasks/W004-fixture-revision.md']
checks=[];broken=[]
for f in files:
 p=R/f;s=p.read_text()
 for target in re.findall(r'\]\(([^)]+)\)',s):
  target=target.strip('<>');path,_,anchor=target.partition('#')
  if ':' in path or not path:continue
  dst=(p.parent/path).resolve();checks.append({'from':f,'target':target,'exists':dst.exists()})
  if not dst.exists():broken.append((f,target))
assert not broken,broken
base='9f6735dcede8e8b2135f89ff10f079a752ed758b'
protected=['docs/tasks/W003/manual-verification.md','docs/tasks/W003-m1-fixture-contracts.md','docs/architecture.md','docs/current-work.md']
for n in protected:assert (R/n).read_bytes()==subprocess.check_output(['git','show',base+':'+n],cwd=R),n
old=subprocess.check_output(['git','show',base+':docs/tasks/W004-fixture-revision.md'],cwd=R,text=True);new=(R/'docs/tasks/W004-fixture-revision.md').read_text()
for title,end in [('### E1.','### E2.'),('### E2.','## Review 结论'),('### RP1.','## PM 验收')]:
 a=old[old.index(title):old.index(end,old.index(title))].rstrip();assert a in new,title
changed=subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines();added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines()
allowed=['tests/fixtures/w003_m1/','tests/support/w003_','tests/support/w004_','docs/tasks/W003/']
assert all(n=='docs/tasks/W004-fixture-revision.md' or any(n.startswith(a) for a in allowed) for n in changed+added)
subprocess.run(['git','diff','--check'],cwd=R,check=True)
print(json.dumps({'links_checked':len(checks),'broken':broken,'protected_files_unchanged':protected,'W004_E1_E2_RP1_preserved':True,'modified_or_removed_tracked_files':len(changed),'new_files':len(added),'scope_valid':True,'checks':checks},ensure_ascii=False,indent=2))

"""Check both complete pytest logs against their exact collections, then package the receipts."""
from collections import Counter
from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
commit = '1a18b1f2d351fa6049ac9c680b3a30365f71e334'
tree = '8558857c114ebf4d37fb531d4f2a8f18346efa85'
files = {'run.py': (root/'run.py').read_bytes(), 'check_matrix.py': Path(__file__).read_bytes()}
rows = {}
collections, subcases = [], []
for v in ('310','312'):
    directory = root/v
    receipt = json.loads((directory/'run.json').read_text())
    assert receipt['rc'] == 0 and not receipt['worktree_status'], receipt
    assert receipt['commit'] == commit and receipt['tree'] == tree
    members = ('python.txt','packages.txt','collection.log','pytest.log','run.json')
    for name in members:
        files[v+'/'+name]=(directory/name).read_bytes()
    lines = (directory/'collection.log').read_text().splitlines()
    nodes = [line for line in lines if line.startswith('tests/') and '::' in line]
    assert re.fullmatch(str(len(nodes))+r' tests collected in .+', lines[-1]), lines[-1]
    assert len(set(nodes)) == len(nodes)
    log = (directory/'pytest.log').read_text()
    passed = re.findall(r'^\[gw\d+\]\s*\[\s*\d+%\]\s*PASSED (tests/.+?)\s*$',log,re.M)
    assert Counter(passed) == Counter(nodes),(v,Counter(nodes)-Counter(passed), Counter(passed)-Counter(nodes))
    parts = re.findall(r'^\[gw\d+\]\s*\[\s*\d+%\]\s*SUBPASSED\((.+?)\) (tests/.+?)\s*$',log,re.M)
    assert len(parts)==len(set(parts))
    summary = log.strip().splitlines()[-1].strip('= ')
    assert f'{len(nodes)} passed, {len(parts)} subtests passed' in summary, summary
    collections.append(nodes)
    subcases.append(set(parts))
    rows[v]={'interpreter':(directory/'python.txt').read_text().strip(),'tests':len(nodes),
             'subtests':len(parts),'seconds':receipt['seconds'],'summary':summary}
assert collections[0] == collections[1] and subcases[0] == subcases[1]
probe = (root/'combination.log').read_bytes()
assert b'normal snapshot 0 nearest_pair_dbu2 25' in probe and b'c14 snapshot 0 nearest_pair_dbu2 16' in probe
assert b'C14 reuse refused' in probe
files['combination.log']=probe
archive = root/'stage-matrix.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
    for name, blob in sorted(files.items()):
        info=tarfile.TarInfo(name); info.size=len(blob); info.mode=0o644
        tf.addfile(info,io.BytesIO(blob))
summary = {'merge_commit':commit,'tree':tree,'scope':'tests/','results':rows,
           'ordered_collection_sha256':sha256(('\n'.join(collections[0])+'\n').encode()).hexdigest(),
           'files_sha256':{k:sha256(b).hexdigest() for k,b in sorted(files.items())},
           'archive_sha256':sha256(archive.read_bytes()).hexdigest()}
(root/'stage-matrix.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(rows))

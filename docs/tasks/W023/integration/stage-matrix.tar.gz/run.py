"""Run the entire suite on an isolated checkout and retain collection and execution evidence."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

v = sys.argv[1]
root = Path('/workspace/work')
out = root / 'w023-stage-results' / v
cwd = root / ('w023-stage' + v)
venv = root / 'w019-pm-tools' / ('env' + v)
py = str(venv / 'bin/python')
env = dict(os.environ, PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONDONTWRITEBYTECODE='1',
           OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MPLCONFIGDIR=str(out/'matplotlib'),
           PATH=str(venv/'bin')+os.pathsep+os.environ['PATH'])
env.pop('PYTHONPATH', None)
def run(args, name):
    with (out/name).open('wb') as f:
        return subprocess.run(args, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT).returncode

def git(*args):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

assert git('rev-parse','HEAD') == '1a18b1f2d351fa6049ac9c680b3a30365f71e334'
assert not git('status','--porcelain')
assert run([py, '-VV'], 'python.txt') == 0
assert run([py, '-c', "from importlib.metadata import distributions;print('\\n'.join(sorted(d.metadata['Name']+'=='+d.version for d in distributions())))"], 'packages.txt') == 0
common = [py, '-B', '-m', 'pytest','tests','-p','no:cacheprovider']
assert run(common + ['-q', '--collect-only'], 'collection.log') == 0
cmd = common + ['-p','xdist','-n','2','--dist','loadfile','-v','--tb=short','--basetemp='+str(out/'pytest-tmp')]
start = time.monotonic()
utc = datetime.now(timezone.utc).isoformat()
ret = run(cmd,'pytest.log')
receipt = {'cwd':str(cwd),'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),
           'args':cmd, 'start_utc':utc, 'seconds':round(time.monotonic()-start,2),
           'rc':ret,'worktree_status':git('status','--porcelain')}
(out/'run.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(ret)

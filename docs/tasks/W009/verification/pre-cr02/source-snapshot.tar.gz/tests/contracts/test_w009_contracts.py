"""Public constructor/wire and captured-owner adversarial checks for W009."""
from __future__ import annotations

from dataclasses import FrozenInstanceError, replace
import os
from pathlib import Path
import subprocess
import sys

import pytest

from layauto_v2.domain.codec import canonical_bytes, decode
from layauto_v2.domain.evidence import SourceRef
from layauto_v2.domain.geometry import GeometryRecordId, GeometryRef, Rect
from layauto_v2.domain.regions import RegionRef
from layauto_v2.normalization import geometry_input
from layauto_v2.normalization import from_parse_result
from layauto_v2.normalization.effective import EffectiveGeometryResult, build_effective_geometry
from layauto_v2.normalization.effective_codec import decode_record, encode_record, record_digest
from layauto_v2.normalization.geometry import build_geometry
from layauto_v2.normalization.geometry_input import GeometryInputError, geometry_from_parse_result
from layauto_v2.state import regions
from test_w008_capture_binding import forged_payload
from w005_cases import FIXTURE
from w007_cases import mutable, read
from test_w008_geometry_wire import replace_input


@pytest.fixture(scope='module')
def accepted():
    return build_effective_geometry(build_geometry(geometry_from_parse_result(read(FIXTURE))))


def test_closed_records_roundtrip_and_no_aliases(accepted):
    draft = accepted.value
    row = draft.records[0]
    region = row.regions[0]
    values = [accepted, draft, draft.operators, row, region, region.pieces[0], region.ref]
    for value in values:
        wire = encode_record(value)
        rebuilt = decode_record(wire)
        assert rebuilt == value
        assert encode_record(rebuilt) == wire
        assert record_digest(rebuilt) == record_digest(value)
        with pytest.raises(FrozenInstanceError):
            value.unexpected = 'mutation'
    rows = list(draft.records)
    rebuilt = replace(draft, records=rows)
    rows.clear()
    assert rebuilt == draft
    rectangles = list(region.rectangles)
    sources = list(region.contributors)
    rebuilt_region = replace(region, rectangles=rectangles, contributors=sources)
    rectangles.clear()
    sources.clear()
    assert rebuilt_region == region
    payload = mutable(draft.physical.payload)
    copied = replace(draft.physical, payload=payload)
    payload['operators']['rectangle_set_difference/1'] = 'caller mutation'
    assert copied == draft.physical


@pytest.mark.parametrize('change', ['missing', 'duplicate', 'foreign_record', 'unit', 'operator',
                                    'foreign_source', 'omit_region', 'duplicate_region', 'extra_region',
                                    'geometry', 'schema', 'physical_owner', 'drawn_owner'])
def test_aggregate_rejects_incomplete_or_foreign_regions(accepted, change):
    draft = accepted.value
    row = draft.records[0]
    region = row.regions[0]
    with pytest.raises(ValueError):
        if change == 'missing':
            replace(draft, records=draft.records[1:])
        elif change == 'duplicate':
            replace(draft, records=draft.records + draft.records[:1])
        elif change == 'foreign_record':
            replace(draft, records=(replace(row, record_id=GeometryRecordId('1' * 64)),) + draft.records[1:])
        elif change == 'unit':
            replace(draft, records=(replace(row, unit_ref=GeometryRef('unit', '1' * 64)),) + draft.records[1:])
        elif change == 'operator':
            replace(draft, records=(replace(row, operator_ref=RegionRef('operators', '1' * 64)),) + draft.records[1:])
        elif change == 'foreign_source':
            replace(draft, records=(replace(row, contributors=(GeometryRecordId('2' * 64),)),) + draft.records[1:])
        elif change == 'omit_region':
            replace(draft, records=(replace(row, regions=()),) + draft.records[1:])
        elif change == 'duplicate_region':
            replace(draft, records=(replace(row, regions=row.regions + row.regions[:1]),) + draft.records[1:])
        elif change == 'extra_region':
            extra = replace(region, rectangles=(Rect(-7, -7, -2, -2),))
            replace(draft, records=(replace(row, regions=row.regions + (extra,)),) + draft.records[1:])
        elif change == 'geometry':
            wrong = replace(region, rectangles=(Rect(-1, -1, 150, 199),))
            replace(draft, records=(replace(row, regions=(wrong,) + row.regions[1:]),) + draft.records[1:])
        elif change == 'schema':
            replace(draft, schema_version='foreign/1')
        elif change == 'physical_owner':
            ref = draft.physical.sources[0]
            evidence = replace(draft.physical, sources=(SourceRef('foreign.json', ref.sha256),))
            wrong = replace(draft, operators=replace(draft.operators, physical=evidence))
            replace(accepted, value=wrong)
        else:
            ref = draft.operators.drawn.sources[0]
            evidence = replace(draft.operators.drawn, sources=(SourceRef('foreign.json', ref.sha256),))
            replace(draft, operators=replace(draft.operators, drawn=evidence))


@pytest.mark.parametrize('change', ['no_value', 'bad_status', 'error_on_valid', 'issues', 'facts', 'schema'])
def test_result_discriminators_and_facts_are_enforced(accepted, change):
    with pytest.raises(ValueError):
        if change == 'no_value': replace(accepted, value=None)
        elif change == 'bad_status': replace(accepted, status='complete')
        elif change == 'error_on_valid': replace(accepted, status='error', value=None)
        elif change == 'issues': replace(accepted, issues=('invented',))
        elif change == 'facts': replace(accepted, completed=accepted.completed[1:])
        else: replace(accepted, schema_version='foreign/1')


def test_grouped_physical_payload_forgery_cannot_enter_success(accepted):
    def mutate(doc):
        doc['physical']['operators']['rectangle_set_difference/1'] = 'bbox only'
    forged = forged_payload(accepted.input.input.parse, 'tech', mutate)
    with pytest.raises(GeometryInputError):
        geometry_from_parse_result(forged)
    tree = mutable(decode(encode_record(accepted)))
    captured = mutable(decode(tree['record']['fields']['input']['geometry_record']))
    assert replace_input(captured, from_parse_result(forged))
    tree['record']['fields']['input']['geometry_record'] = canonical_bytes(captured)
    with pytest.raises(GeometryInputError):
        decode_record(canonical_bytes(tree))


@pytest.mark.parametrize('target', ['state', 'adapter'])
@pytest.mark.parametrize('failure', [RuntimeError('unexpected'), ValueError('unexpected value'),
                                    TypeError('unexpected type'), KeyError('unexpected key'),
                                    KeyboardInterrupt(), SystemExit(17)])
def test_builder_unexpected_exception_identity(accepted, monkeypatch, target, failure):
    def broken(*args, **kwargs):
        raise failure
    if target == 'state':
        monkeypatch.setattr(regions, 'slab_difference', broken)
    else:
        monkeypatch.setattr('layauto_v2.normalization.effective.build_effective_draft', broken)
    with pytest.raises(type(failure)) as caught:
        build_effective_geometry(accepted.input)
    assert caught.value is failure


@pytest.mark.parametrize('failure', [RuntimeError('decoder bug'), ValueError('decoder bug value'),
                                    TypeError('decoder bug type'), KeyError('decoder bug key'),
                                    KeyboardInterrupt(), SystemExit(23)])
def test_nested_capture_decoder_unexpected_exception_identity(accepted, monkeypatch, failure):
    wire = encode_record(accepted)
    def broken(*args, **kwargs):
        raise failure
    monkeypatch.setattr(geometry_input, 'load_document', broken)
    with pytest.raises(type(failure)) as caught:
        decode_record(wire)
    assert caught.value is failure


@pytest.mark.parametrize('enclosing', ['draft', 'result'])
@pytest.mark.parametrize('failure', [RuntimeError('algorithm bug'), ValueError('algorithm bug value'),
                                    TypeError('algorithm bug type'), KeyError('algorithm bug key'),
                                    AttributeError('algorithm bug attribute'), IndexError('algorithm bug index'),
                                    KeyboardInterrupt(), SystemExit(29)])
def test_neutral_aggregate_decode_preserves_algorithm_exception_identity(accepted, monkeypatch, enclosing, failure):
    wire = encode_record(accepted.value if enclosing == 'draft' else accepted)
    def broken(*args, **kwargs):
        raise failure
    monkeypatch.setattr(regions, 'slab_difference', broken)
    with pytest.raises(type(failure)) as caught:
        decode_record(wire)
    assert caught.value is failure


@pytest.mark.parametrize('change', ['outer', 'fields', 'nested', 'scalar_collection', 'wrong_type'])
def test_closed_wire_rejects_nested_malformations(accepted, change):
    tree = mutable(decode(encode_record(accepted.value.records[0].regions[0])))
    if change == 'outer': tree['extra'] = True
    elif change == 'fields': tree['record']['fields']['extra'] = {'scalar': 1}
    elif change == 'nested': tree['record']['fields']['unit_ref']['extra'] = True
    elif change == 'scalar_collection': tree['record']['fields']['role'] = {'scalar': []}
    else: tree['record']['fields']['unit_ref'] = {'scalar': 'foreign'}
    with pytest.raises(ValueError):
        decode_record(canonical_bytes(tree))


def test_nested_result_wire_rejects_missing_region(accepted):
    tree = mutable(decode(encode_record(accepted)))
    rows = tree['record']['fields']['value']['fields']['records']['tuple']
    rows.pop()
    with pytest.raises(ValueError):
        decode_record(canonical_bytes(tree))


def test_public_builder_requires_w008_success(accepted):
    with pytest.raises(ValueError):
        build_effective_geometry(accepted.input.input)
    with pytest.raises(ValueError):
        EffectiveGeometryResult('success', accepted.value, (), accepted.completed, None)


def test_reconstruction_is_stable_across_process_hash_seeds(accepted):
    script = '''
from pathlib import Path
from layauto_v2.importers import read_inputs
from layauto_v2.normalization.geometry_input import geometry_from_parse_result
from layauto_v2.normalization.geometry import build_geometry
from layauto_v2.normalization.effective import build_effective_geometry
from layauto_v2.normalization.effective_codec import record_digest
r = build_effective_geometry(build_geometry(geometry_from_parse_result(read_inputs(Path(%r)))))
print(record_digest(r), r.value.semantic_digest, r.value.ref.sha256)
''' % str(FIXTURE / 'site_config.yaml')
    expected = ' '.join((record_digest(accepted), accepted.value.semantic_digest, accepted.value.ref.sha256))
    for seed in ('1', '73', 'random'):
        env = dict(os.environ, PYTHONHASHSEED=seed)
        result = subprocess.run([sys.executable, '-B', '-c', script], cwd=Path.cwd(),
                                env=env, text=True, capture_output=True, check=True)
        assert result.stdout.strip() == expected

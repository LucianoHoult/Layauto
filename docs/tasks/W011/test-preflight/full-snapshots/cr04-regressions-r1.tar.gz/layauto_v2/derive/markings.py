"""v2 derive.markings placeholder.

Responsibilities are defined in docs/architecture.md. This module intentionally
contains no legacy MVP implementation yet.
"""

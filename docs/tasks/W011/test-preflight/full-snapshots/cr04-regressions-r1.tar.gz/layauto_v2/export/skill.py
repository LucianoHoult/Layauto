"""v2 export.skill placeholder.

Responsibilities are defined in docs/architecture.md. This module intentionally
contains no legacy MVP implementation yet.
"""

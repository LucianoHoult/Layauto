from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import yaml
from analysis_inputs import load, rebind, write
from analysis_projection_inputs import COORDINATE, projected_manifest
from layauto_v2.analysis import AnalysisRequest, OccupancyRequest, analyze_cell
from layauto_v2.normalization import analysis_occupancy as adapter

def call(root, select, *, binds):
    reads = Counter()
    actual = Path.read_bytes
    def counted(path):
        reads[path] += 1
        return actual(path)
    options = {} if select is None else {'occupancy': OccupancyRequest(0, select)}
    with patch.object(Path, 'read_bytes', counted), patch.object(adapter, '_bind_model', wraps=adapter._bind_model) as bind, patch.object(adapter, 'build_discrete_occupancy', side_effect=AssertionError('blocked projection')):
        result = analyze_cell(AnalysisRequest(root / 'analysis.json'), **options)
    assert reads and max(reads.values()) == 1 and bind.call_count == binds
    return result, len(reads)

def assert_report(root, result, expected):
    report = json.loads(result.report_json)
    rows = report['objects']
    summary = rows[report['facets']['occupancy']['ref']]
    entries = [rows[r['ref']]['fields'] for r in rows[summary['issues']['ref']]]
    found = {}
    for entry in entries:
        location = entry['source']
        source = report['captures'][location['capture']]
        assert sha256((root / source['uri']).read_bytes()).hexdigest() == source['sha256']
        found[entry['code']] = (source['uri'], location['field'], source['sha256'])
    assert len(found) == len(entries)
    assert found == {q.code: (q.source.uri, q.source.field, q.source.sha256) for q in result.occupancy.issues}
    assert {k: v[:2] for k,v in found.items()} == expected
    assert result.occupancy.value is None
    return found

c = {'InvalidProjectionDeclaration': (COORDINATE, '/coordinate_projection/units_ref')}
e = {'UnsupportedRegionOperator': ('tech/physical.json', '/operators/terminal_split~11')}
with TemporaryDirectory() as tmp:
    root = Path(tmp)
    projected_manifest(root)
    owner = root / COORDINATE
    phys = root / 'tech/physical.json'
    oc, op = owner.read_bytes(), phys.read_bytes()
    coordinate = yaml.safe_load(oc)
    coordinate['coordinate_projection']['units_ref'] = 'formats#/absent'
    physical = json.loads(op)
    physical['operators']['terminal_split/1'] = 'unimplemented in review'
    seen = {}
    for name, bad_coord, bad_phys, expected in [('coordinate-only', True, False, c),('effective-only', False, True, e),('both', True, True, c | e)]:
        owner.write_bytes(oc)
        phys.write_bytes(op)
        if bad_coord: write(owner, coordinate)
        if bad_phys: write(phys, physical)
        rebind(root)
        result, reads = call(root, True, binds=1)
        locations = assert_report(root, result, expected)
        seen[name] = locations
        assert len(result.local.facets.drawn.value.layout.records) == 40
        assert result.request_status == ('unsupported' if bad_phys else 'completed')
        assert result.occupancy.status == ('not_evaluated' if bad_phys else 'invalid_declaration')
        print(name, result.request_status, result.occupancy.status, reads, locations)
    assert seen['both'] == seen['coordinate-only'] | seen['effective-only']
    drawn, _ = call(root, False, binds=1)
    assert_report(root, drawn, c)
    assert drawn.occupancy.dependencies == ('coordinate',)
    plain, _ = call(root, None, binds=0)
    assert plain.occupancy is None and 'occupancy' not in json.loads(plain.report_json)['facets']
    assert drawn.local == plain.local == result.local
    assert drawn.request_status == plain.request_status == result.request_status
    assert drawn.findings == plain.findings == result.findings
    assert any(f.code == 'UnsupportedRegionOperator' for f in plain.findings)
    # Unbound changed bytes must short-circuit before the optional binder.
    owner.write_bytes(owner.read_bytes() + b'\n')
    stale, reads = call(root, True, binds=0)
    assert stale.request_status == 'rejected' and stale.local is None
    assert stale.occupancy.value is None and stale.occupancy.dependencies == ('local_authentication',)
    assert {item.code for item in stale.occupancy.issues} == {'ClosureHashMismatch'}
    print('drawn-only / no query / stale owner checks passed')
